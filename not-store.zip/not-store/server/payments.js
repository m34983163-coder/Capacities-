// Payment provider boundary. NOTHING here ever reports a successful payment unless a real provider confirms it.
// To accept real payments: implement a provider below (e.g. Stripe Checkout Session created SERVER-SIDE with
// process.env.STRIPE_SECRET_KEY), return its hosted-payment URL, and mark orders paid ONLY from a verified webhook.

export function paymentStatusForNewOrder() {
  const provider = (process.env.PAYMENT_PROVIDER || "none").toLowerCase();
  if (provider === "none") return { paymentStatus: "not_configured", redirectUrl: null };
  // Provider named but not implemented in this codebase: stay honest.
  return { paymentStatus: "unpaid", redirectUrl: null };
}
