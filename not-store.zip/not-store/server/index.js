import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { paymentStatusForNewOrder } from "./payments.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const DATA = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA, "orders.json");
const INV_FILE = path.join(DATA, "inventory.json");

// minimal .env loader (no dependencies)
try {
  for (const line of fs.readFileSync(path.join(ROOT, ".env"), "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch { /* no .env */ }

const PORT = Number(process.env.PORT || 3000);
const FREE_SHIPPING_OVER = 2500, FLAT_SHIPPING = 25, MAX_PER_LINE = 5;

const readJson = (f, fallback) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return fallback; } };
const writeJson = (f, v) => { fs.mkdirSync(DATA, { recursive: true }); const t = f + ".tmp"; fs.writeFileSync(t, JSON.stringify(v, null, 2)); fs.renameSync(t, f); };
const baseCatalog = () => readJson(path.join(PUBLIC, "data", "products.json"), { products: [] }).products;

function catalogWithStock() {
  const inv = readJson(INV_FILE, {});
  return baseCatalog().map((p) => ({ ...p, variants: p.variants.map((v) => ({ ...v, stock: inv[`${p.id}:${v.id}`] ?? v.stock })) }));
}

const json = (res, code, body) => { const s = JSON.stringify(body); res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(s); };

const hits = new Map();
const limited = (ip) => { const now = Date.now(); const a = (hits.get(ip) || []).filter((t) => now - t < 60_000); a.push(now); hits.set(ip, a); return a.length > 20; };

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", (c) => { size += c.length; if (size > 50_000) { reject(new Error("too large")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); } catch { reject(new Error("bad json")); } });
    req.on("error", reject);
  });
}

const str = (v, max = 200) => (typeof v === "string" ? v.trim().slice(0, max) : "");
function validateCustomer(c = {}) {
  const f = {};
  const x = { name: str(c.name, 120), email: str(c.email, 160), phone: str(c.phone, 40), address: str(c.address, 240), city: str(c.city, 100), country: str(c.country, 80) };
  if (x.name.length < 2) f.name = "Enter your full name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(x.email)) f.email = "Enter a valid email address.";
  const digits = x.phone.replace(/[\s()\-+.]/g, "");
  if (!/^[\d\s()\-+.]+$/.test(x.phone) || !/^\d{7,15}$/.test(digits)) f.phone = "Enter a valid phone number (7–15 digits).";
  if (x.address.length < 5) f.address = "Enter your street address.";
  if (x.city.length < 2) f.city = "Enter your city.";
  if (!x.country) f.country = "Select your country.";
  return { customer: x, fields: f };
}

let orderLock = Promise.resolve();
function createOrder(body) {
  const { customer, fields } = validateCustomer(body.customer);
  if (Object.keys(fields).length) return { code: 422, body: { error: "Please correct the highlighted fields.", fields } };
  if (!Array.isArray(body.items) || !body.items.length || body.items.length > 20) return { code: 422, body: { error: "Your cart is empty." } };

  const cat = catalogWithStock();
  const merged = new Map();
  for (const it of body.items) {
    const key = `${str(it?.productId, 80)}:${str(it?.variantId, 40)}`;
    const qty = Number(it?.qty);
    if (!Number.isInteger(qty) || qty < 1) return { code: 422, body: { error: "Invalid quantity in cart." } };
    merged.set(key, (merged.get(key) || 0) + qty);
  }
  const lines = [];
  for (const [key, qty] of merged) {
    const [pid, vid] = key.split(":");
    const p = cat.find((x) => x.id === pid); const v = p?.variants.find((x) => x.id === vid);
    if (!p || !v) return { code: 409, body: { error: "A watch in your cart is no longer available. Please review your cart." } };
    if (qty > MAX_PER_LINE) return { code: 409, body: { error: `Maximum ${MAX_PER_LINE} per watch.` } };
    if (v.stock < qty) return { code: 409, body: { error: v.stock <= 0 ? `${p.name} ${v.label} is sold out.` : `Only ${v.stock} of ${p.name} ${v.label} left. Please update your cart.` } };
    lines.push({ productId: p.id, variantId: v.id, name: p.name, variant: v.label, qty, unitPrice: p.price }); // price always from server catalogue
  }
  const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.qty, 0);
  const shipping = subtotal >= FREE_SHIPPING_OVER ? 0 : FLAT_SHIPPING;
  const { paymentStatus } = paymentStatusForNewOrder();
  const order = { id: "NOT-" + crypto.randomBytes(5).toString("hex").toUpperCase(), createdAt: new Date().toISOString(), customer, lines, subtotal, shipping, total: subtotal + shipping, currency: "USD", status: "pending_payment", paymentStatus };

  const inv = readJson(INV_FILE, {});
  for (const l of lines) { const k = `${l.productId}:${l.variantId}`; const base = baseCatalog().find((p) => p.id === l.productId).variants.find((v) => v.id === l.variantId).stock; inv[k] = (inv[k] ?? base) - l.qty; }
  const orders = readJson(ORDERS_FILE, []); orders.push(order);
  writeJson(ORDERS_FILE, orders); writeJson(INV_FILE, inv);
  return { code: 201, body: { order } };
}

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".jpg": "image/jpeg", ".png": "image/png", ".svg": "image/svg+xml", ".webp": "image/webp", ".ico": "image/x-icon" };

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  try {
    if (url.pathname.startsWith("/api/")) {
      if (req.method === "GET" && url.pathname === "/api/products") return json(res, 200, { products: catalogWithStock() });
      if (req.method === "POST" && url.pathname === "/api/orders") {
        if (limited(req.socket.remoteAddress || "?")) return json(res, 429, { error: "Too many requests. Please wait a minute." });
        let body; try { body = await readBody(req); } catch { return json(res, 400, { error: "Invalid request." }); }
        const result = await (orderLock = orderLock.then(() => createOrder(body)));
        return json(res, result.code, result.body);
      }
      const m = /^\/api\/orders\/([\w-]+)$/.exec(url.pathname);
      if (req.method === "GET" && m) { const o = readJson(ORDERS_FILE, []).find((x) => x.id === m[1]); return o ? json(res, 200, { order: o }) : json(res, 404, { error: "Not found" }); }
      return json(res, 404, { error: "Not found" });
    }
    if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); return res.end(); }
    let rel = decodeURIComponent(url.pathname); if (rel.endsWith("/")) rel += "index.html";
    const file = path.normalize(path.join(PUBLIC, rel));
    if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404, { "Content-Type": "text/plain" }); return res.end("Not found"); }
      const ext = path.extname(file);
      res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream", "Cache-Control": ext === ".jpg" ? "public, max-age=604800" : "no-cache", "X-Content-Type-Options": "nosniff" });
      res.end(data);
    });
  } catch (e) { console.error(e); json(res, 500, { error: "Server error" }); }
});

server.listen(PORT, () => console.log(`NOT store running on http://localhost:${PORT}`));
