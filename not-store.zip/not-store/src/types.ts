export interface Variant {
  id: string;
  label: string;
  sku: string;
  stock: number;
}

export interface Spec {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  collection: string;
  price: number;
  currency: "USD";
  shortDescription: string;
  description: string;
  /** 4:5 card image */
  image: string;
  /** wide cinematic hero image */
  heroImage: string;
  /** small cutout used by the hero selector */
  thumb: string;
  gallery: { src: string; alt: string }[];
  colors: { name: string; hex: string }[];
  materials: string[];
  specs: Spec[];
  featured: boolean;
  /** hero background tint */
  accent: string;
  variants: Variant[];
  /** all current catalogue data is sample data */
  sample: boolean;
}

export type StockStatus = "in_stock" | "low_stock" | "out_of_stock";

export interface CartLine {
  productId: string;
  variantId: string;
  qty: number;
}

export interface Customer {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
}

export interface Order {
  id: string;
  createdAt: string;
  customer: Customer;
  lines: { productId: string; variantId: string; name: string; variant: string; qty: number; unitPrice: number }[];
  subtotal: number;
  shipping: number;
  total: number;
  currency: "USD";
  status: "pending_payment";
  paymentStatus: "not_configured" | "unpaid";
}
