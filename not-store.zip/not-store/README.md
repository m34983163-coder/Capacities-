# NOT — luxury watch store

TypeScript front end (compiled to native ES modules, no bundler, no runtime dependencies) + a small dependency-free Node server for the catalogue, inventory and orders.

## Run
```bash
npm install          # only installs TypeScript (dev)
npm run build        # compiles src/ -> public/js
npm start            # http://localhost:3000   (PORT env var to change)
npm run dev          # tsc --watch + server
```
Copy `.env.example` to `.env` if you need to change settings.

## Structure
- `public/data/products.json` — SAMPLE catalogue (single source of truth; the server serves it with live stock). Replace prices, sizes, specs with verified data.
- `public/img/` — images cropped from the supplied moodboard. Replace the files (same names) with high-resolution photography.
- `src/` — types, store (catalogue + cart), router, `ui/` (hero, collection, cart drawer, quick view, search, menu), `pages/`.
- `server/index.js` — `/api/products`, `POST /api/orders` (re-validates items, stock and prices server-side, decrements inventory), `GET /api/orders/:id`. Orders are written to `server/data/orders.json`.

## Payments — NOT configured
Orders are stored as `pending_payment` / `not_configured`. The site never claims a payment succeeded and collects no card data. To accept payments: create a hosted checkout session server-side in `server/payments.js` (e.g. Stripe, with `STRIPE_SECRET_KEY` in `.env`) and mark orders paid only from a verified webhook.

## Deploy
Any Node 18+ host: run `npm ci && npm run build && npm start`. Replace the JSON file storage with a real database before real traffic.

## Still needs configuration
Payment provider, order/notification email, a database, real product data/photography, real shipping rates and return policy, hosting + domain.
